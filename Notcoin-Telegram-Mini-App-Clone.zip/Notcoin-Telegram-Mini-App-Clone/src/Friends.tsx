import React from 'react';

const Friends = () => {
  return (
    <div className="flex-grow flex flex-col items-center justify-center text-white font-medium">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-6">Invite friends!</h1>
        <div className="w-full max-w-md px-4 py-6 bg-gray-800 rounded-lg shadow-md">
          <div className="mb-4">
            <div className="bg-gray-700 p-4 rounded-lg flex justify-between items-center">
              <span>Invite a friend</span>
              <span className="bg-yellow-500 text-black px-3 py-1 rounded-lg">+5,000</span>
            </div>
          </div>
          <div className="mb-4">
            <div className="bg-gray-700 p-4 rounded-lg flex justify-between items-center">
              <span>Invite a friend with Telegram Premium</span>
              <span className="bg-yellow-500 text-black px-3 py-1 rounded-lg">+10,000</span>
            </div>
          </div>
          <div className="text-center">
            <p className="mb-4">List of your friends</p>
            <p className="mb-4">You haven't invited anyone yet</p>
            <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              Invite a friend
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Friends;
