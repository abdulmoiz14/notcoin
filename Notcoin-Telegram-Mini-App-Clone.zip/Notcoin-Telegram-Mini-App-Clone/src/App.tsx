import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, useLocation } from 'react-router-dom';
import './index.css';
import { dragon, coin, highVoltage, tap, friends, earn, wallet } from './images'; // Update with your actual image paths
import Friends from './Friends';
import Earn from './Earn'; // Import the Earn component

const Header = ({ points }: { points: number }) => (
  <div className="fixed top-0 left-0 w-full px-4 pt-8 z-10 flex flex-col items-center text-white">
    <div className="mt-12 text-5xl font-bold flex items-center">
      <img src={coin} width={44} height={44} />
      <span className="ml-2">{points.toLocaleString()}</span>
    </div>
    <div className="text-base mt-2 flex items-center">
      <span className="ml-1">Level 1/10</span>
    </div>
    <div className="w-full bg-[#333] rounded-full mt-2">
      <div className="bg-[#ffcc00] h-2 rounded-full" style={{ width: `${(points % 100) * 1}%` }}></div>
    </div>
  </div>
);

const AppContent = () => {
  const [points, setPoints] = useState(109391);
  const [energy, setEnergy] = useState(210);
  const [clicks, setClicks] = useState<{ id: number, x: number, y: number }[]>([]);
  const pointsToAdd = 10;
  const energyToReduce = 10;
  const location = useLocation();

  const handleClick = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    if (energy - energyToReduce < 0) {
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setPoints(points + pointsToAdd);
    setEnergy(energy - energyToReduce < 0 ? 0 : energy - energyToReduce);
    setClicks([...clicks, { id: Date.now(), x, y }]);
  };

  const handleAnimationEnd = (id: number) => {
    setClicks((prevClicks) => prevClicks.filter(click => click.id !== id));
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setEnergy((prevEnergy) => Math.min(prevEnergy + 1, 4000));
    }, 100); // Restore 10 energy points every second

    return () => clearInterval(interval); // Clear interval on component unmount
  }, []);

  return (
    <div className="bg-gradient-main min-h-screen flex flex-col items-center text-white font-medium">
      <div className="absolute inset-0 h-1/2 bg-gradient-overlay z-0"></div>
      <div className="absolute inset-0 flex items-center justify-center z-0">
        <div className="radial-gradient-overlay"></div>
      </div>
      <div className="w-full z-10 min-h-screen flex flex-col items-center text-white">
        {location.pathname === '/' && <Header points={points} />}

        <Routes>
          <Route
            path="/"
            element={
              <div className="flex-grow flex items-center justify-center">
                <div className="relative mt-4" onClick={handleClick}>
                  <img src={dragon} width={256} height={256} alt="Dragon" />
                  {clicks.map((click) => (
                    <div
                      key={click.id}
                      className="absolute text-5xl font-bold opacity-0"
                      style={{
                        top: `${click.y - 42}px`,
                        left: `${click.x - 28}px`,
                        animation: `float 1s ease-out`
                      }}
                      onAnimationEnd={() => handleAnimationEnd(click.id)}
                    >
                      +10
                    </div>
                  ))}
                </div>
              </div>
            }
          />
          <Route path="/friends" element={<Friends />} />
          <Route path="/earn" element={<Earn />} /> {/* Add Earn route */}
        </Routes>

        <div className="fixed bottom-0 left-0 w-full px-4 pb-4 z-10">
          <div className="w-full flex justify-center items-center">
            <div className="w-full max-w-md bg-[#333] py-4 rounded-2xl flex justify-around">
              <div className="flex items-center justify-center">
                <img src={highVoltage} width={44} height={44} alt="High Voltage" />
                <div className="ml-2 text-left">
                  <span className="text-white text-2xl font-bold block">{energy}</span>
                  <span className="text-white text-large opacity-75">/ 4000</span>
                </div>
              </div>
              <div className="h-[48px] w-[2px] bg-[#444]"></div>
              <Link to="/" className="flex flex-col items-center gap-1">
                <img src={tap} width={24} height={24} alt="Tap" />
                <span>Tap</span>
              </Link>
              <div className="h-[48px] w-[2px] bg-[#444]"></div>
              <Link to="/friends" className="flex flex-col items-center gap-1">
                <img src={friends} width={24} height={24} alt="Friends" />
                <span>Friends</span>
              </Link>
              <div className="h-[48px] w-[2px] bg-[#444]"></div>
              <Link to="/earn" className="flex flex-col items-center gap-1"> {/* Update the link to the Earn route */}
                <img src={earn} width={24} height={24} alt="Earn" />
                <span>Earn</span>
              </Link>
              <div className="h-[48px] w-[2px] bg-[#444]"></div>
              <div className="flex flex-col items-center gap-1">
                <img src={wallet} width={24} height={24} alt="Wallet" />
                <span>Wallet</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const App = () => (
  <Router>
    <AppContent />
  </Router>
);

export default App;
